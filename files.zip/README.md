# redis-clone

A Redis server, built from scratch in Python. No external dependencies,
no `redis` package — just sockets and the standard library.

It speaks real RESP (the wire protocol Redis uses), so real tools can talk
to it: `redis-cli`, `redis-py`, `nc`, even `telnet`.

Based on the "Build your own Database"-style project from
[build-your-own-x](https://github.com/codecrafters-io/build-your-own-x).

## Quick start

```bash
python3 server.py --port 6380
```

In another terminal:

```bash
redis-cli -p 6380 SET foo bar
redis-cli -p 6380 GET foo
redis-cli -p 6380 LPUSH mylist a b c
redis-cli -p 6380 LRANGE mylist 0 -1
```

No `redis-cli` installed? Plain netcat works too, because the server also
understands Redis's simpler "inline command" format:

```bash
printf 'PING\r\nSET foo bar\r\nGET foo\r\n' | nc localhost 6380
```

Or run the included test client, which speaks RESP directly over a raw
socket and checks ~40 behaviors end to end:

```bash
python3 test_client.py --port 6380
```

## How it's built

| File              | What it does |
|-------------------|--------------|
| `resp.py`         | Encodes Python values into RESP wire format, and incrementally parses incoming bytes back into command arrays. This is the entire "protocol" layer — get this right and any Redis client works unmodified. |
| `database.py`      | The actual key/value store: one dict for values, one for expiry timestamps. Expiry is checked lazily on access, plus swept during `KEYS`/`DBSIZE`. |
| `commands.py`      | Every supported command as a small function, registered into a `COMMANDS` dispatch table via a `@command(...)` decorator. |
| `persistence.py`   | Snapshotting to disk (a JSON stand-in for Redis's RDB format) so data survives a restart. |
| `server.py`        | The event loop. Single-threaded, using `selectors` to multiplex many client sockets — the same architectural choice real Redis makes, which is why Redis doesn't need locks around its data structures. |
| `test_client.py`   | A hand-rolled RESP client used to smoke-test the server (also proves the protocol implementation is correct from an independent code path). |

### Why single-threaded?

This is the most interesting design decision in real Redis, and it's cheap
to copy: one thread runs an event loop (`selectors.select`), waking up
whenever any client socket is readable. Because command execution never
overlaps across clients, the data store needs zero locking. The trade-off
—a slow command blocks every other client—is the same trade-off real Redis
accepts, which is why Redis commands are designed to be fast and why
genuinely slow operations (like a full `KEYS *` scan) are discouraged in
production.

### Wire protocol walkthrough

A client sends a command as a RESP array of bulk strings:

```
*3\r\n$3\r\nSET\r\n$3\r\nfoo\r\n$3\r\nbar\r\n
```

That's `["SET", "foo", "bar"]` — array of 3, each element length-prefixed.
The server replies with a simple string:

```
+OK\r\n
```

`resp.py`'s `RESPParser` reads bytes off the socket incrementally (TCP
gives no guarantee a full command arrives in one `recv()`), and only
consumes bytes from its internal buffer once a *complete* command has
arrived — otherwise it returns `None` and waits for more data next time
the socket is readable.

## Supported commands

- **Generic**: `PING`, `ECHO`, `SELECT`, `FLUSHALL`/`FLUSHDB`, `DBSIZE`,
  `KEYS`, `EXISTS`, `DEL`, `TYPE`, `COMMAND`, `CONFIG`, `INFO`, `SAVE`,
  `BGSAVE`
- **Expiry**: `EXPIRE`, `PEXPIRE`, `TTL`, `PTTL`, `PERSIST`
- **Strings**: `SET` (with `NX`/`XX`/`EX`/`PX`/`KEEPTTL`), `GET`, `GETSET`,
  `APPEND`, `STRLEN`, `INCR`, `DECR`, `INCRBY`, `DECRBY`
- **Lists**: `LPUSH`, `RPUSH`, `LPOP`, `RPOP` (with optional count),
  `LRANGE`, `LLEN`, `LINDEX`
- **Hashes**: `HSET`, `HGET`, `HDEL`, `HGETALL`, `HEXISTS`, `HKEYS`,
  `HVALS`, `HLEN`, `HINCRBY`
- **Sets**: `SADD`, `SREM`, `SMEMBERS`, `SISMEMBER`, `SCARD`

Everything else returns a real RESP error (`ERR unknown command '...'`),
so clients don't hang — they just get told the command isn't supported.

## What's deliberately left out (good next steps if you want to extend it)

- **Multiple databases** — `SELECT` accepts only `0`; a real server has 16.
- **Replication / clustering** — Redis's biggest feature, and a project of
  its own.
- **Binary-safe values** — strings here are decoded as UTF-8 text; real
  Redis treats all values as raw bytes.
- **Pub/Sub** (`SUBSCRIBE`/`PUBLISH`) — a great follow-up: it mostly means
  adding a "subscriber" mode to `Client` and pushing messages onto sockets
  outside of the normal request/response cycle.
- **Sorted sets** (`ZADD`/`ZRANGE`) — needs a data structure that keeps
  members ordered by score (a skip list, in real Redis); Python's
  `sortedcontainers` or a manually maintained sorted list would work here.
- **Compact binary RDB format** and **AOF (append-only file) persistence**
  — `persistence.py`'s JSON snapshot captures the idea but not the
  performance characteristics of the real thing.

## Testing manually with redis-cli

```bash
$ redis-cli -p 6380
127.0.0.1:6380> SET greeting hello
OK
127.0.0.1:6380> GET greeting
"hello"
127.0.0.1:6380> HSET user:1 name Claude role assistant
(integer) 2
127.0.0.1:6380> HGETALL user:1
1) "name"
2) "Claude"
3) "role"
4) "assistant"
127.0.0.1:6380> EXPIRE greeting 60
(integer) 1
127.0.0.1:6380> TTL greeting
(integer) 60
```

Data auto-saves every 30 seconds and on clean shutdown (Ctrl+C), and
reloads from `dump.json` the next time the server starts.
