"""
server.py — a toy Redis server.

Architecture mirrors real Redis on purpose:
  * single-threaded event loop (via `selectors`) multiplexing many client
    sockets — no thread-per-connection, no locks needed for the data store
  * a simple text wire protocol (RESP) that real Redis clients speak
  * commands dispatched through a table (see commands.py)
  * periodic snapshotting to disk so data survives a restart (persistence.py)

Run it:
    python3 server.py --port 6380

Talk to it with the real redis-cli:
    redis-cli -p 6380 SET foo bar
    redis-cli -p 6380 GET foo

...or with nothing but netcat, since inline commands are supported too:
    printf 'PING\r\nSET foo bar\r\nGET foo\r\n' | nc localhost 6380
"""

import argparse
import selectors
import socket
import time

import commands
import persistence
from database import Database
from resp import RESPParser, ProtocolError, RedisError, encode, encode_error

DEFAULT_PORT = 6380
DEFAULT_SNAPSHOT_FILE = "dump.json"
AUTOSAVE_INTERVAL_SECONDS = 30


class Client:
    """Per-connection state: the socket, its incremental RESP parser, and
    anything still waiting to be flushed out (in case a send() would block)."""

    def __init__(self, sock: socket.socket, addr):
        self.sock = sock
        self.addr = addr
        self.parser = RESPParser()
        self.outbuf = bytearray()


class RedisServer:
    def __init__(self, host="0.0.0.0", port=DEFAULT_PORT,
                 snapshot_path=DEFAULT_SNAPSHOT_FILE):
        self.host = host
        self.port = port
        self.snapshot_path = snapshot_path
        self.db = Database()
        persistence.load(self.db, self.snapshot_path)

        self.sel = selectors.DefaultSelector()
        self.clients: dict[socket.socket, Client] = {}
        self._last_autosave = time.time()

    # ---------------------------------------------------------------- run

    def start(self):
        lsock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        lsock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        lsock.bind((self.host, self.port))
        lsock.listen()
        lsock.setblocking(False)
        self.sel.register(lsock, selectors.EVENT_READ, data=None)

        print(f"redis-clone listening on {self.host}:{self.port} "
              f"(snapshot file: {self.snapshot_path})")

        try:
            while True:
                events = self.sel.select(timeout=1.0)
                for key, mask in events:
                    if key.data is None:
                        self._accept(key.fileobj)
                    else:
                        self._service(key, mask)
                self._maybe_autosave()
        except KeyboardInterrupt:
            print("\nShutting down...")
        finally:
            persistence.save(self.db, self.snapshot_path)
            self.sel.close()
            lsock.close()
            print("Snapshot saved. Bye.")

    def _maybe_autosave(self):
        now = time.time()
        if now - self._last_autosave >= AUTOSAVE_INTERVAL_SECONDS:
            persistence.save(self.db, self.snapshot_path)
            self._last_autosave = now

    # ------------------------------------------------------------ sockets

    def _accept(self, lsock: socket.socket):
        conn, addr = lsock.accept()
        conn.setblocking(False)
        client = Client(conn, addr)
        self.clients[conn] = client
        self.sel.register(conn, selectors.EVENT_READ, data=client)

    def _close(self, sock: socket.socket):
        self.clients.pop(sock, None)
        try:
            self.sel.unregister(sock)
        except (KeyError, ValueError):
            pass
        try:
            sock.close()
        except OSError:
            pass

    def _service(self, key, mask):
        sock = key.fileobj
        client = key.data

        if mask & selectors.EVENT_READ:
            try:
                data = sock.recv(65536)
            except (ConnectionResetError, BrokenPipeError, OSError):
                data = b""

            if not data:
                self._close(sock)
                return

            client.parser.feed(data)
            while True:
                try:
                    parsed = client.parser.try_parse()
                except ProtocolError as e:
                    client.outbuf += encode_error(f"ERR Protocol error: {e}")
                    self._flush(sock, client)
                    self._close(sock)
                    return
                if parsed is None:
                    break
                if parsed:
                    self._dispatch(client, parsed)

        if client.outbuf:
            self._flush(sock, client)

    def _dispatch(self, client: Client, args: list):
        name = args[0].upper()
        handler = commands.COMMANDS.get(name)
        try:
            if handler is None:
                raise RedisError(
                    f"ERR unknown command '{args[0]}', with args beginning with: "
                    + ", ".join(repr(a) for a in args[1:3])
                )
            result = handler(self.db, args[1:], self)
            client.outbuf += encode(result)
        except RedisError as e:
            client.outbuf += encode_error(str(e))

    def _flush(self, sock: socket.socket, client: Client):
        try:
            sent = sock.send(client.outbuf)
            del client.outbuf[:sent]
        except BlockingIOError:
            pass
        except OSError:
            self._close(sock)


def main():
    parser = argparse.ArgumentParser(description=__doc__.split("\n\n")[0])
    parser.add_argument("--host", default="0.0.0.0")
    parser.add_argument("--port", type=int, default=DEFAULT_PORT)
    parser.add_argument("--dump-file", default=DEFAULT_SNAPSHOT_FILE,
                         help="path to load/save the snapshot file")
    args = parser.parse_args()

    server = RedisServer(host=args.host, port=args.port,
                          snapshot_path=args.dump_file)
    server.start()


if __name__ == "__main__":
    main()
