"""
persistence.py — a tiny stand-in for Redis's RDB snapshotting.

Real Redis dumps a compact binary format; we dump readable JSON instead,
since the point here is showing *how* snapshot persistence fits into the
server, not squeezing out bytes. Sets get converted to lists (JSON has no
set type) and converted back to sets on load.
"""

import json
import os


def save(db, path: str) -> None:
    snapshot = {"data": {}, "expires": db.expires}
    for key, value in db.data.items():
        if isinstance(value, set):
            snapshot["data"][key] = {"type": "set", "value": list(value)}
        elif isinstance(value, list):
            snapshot["data"][key] = {"type": "list", "value": value}
        elif isinstance(value, dict):
            snapshot["data"][key] = {"type": "hash", "value": value}
        else:
            snapshot["data"][key] = {"type": "string", "value": value}

    tmp_path = path + ".tmp"
    with open(tmp_path, "w") as f:
        json.dump(snapshot, f)
    os.replace(tmp_path, path)  # atomic on POSIX: no half-written dump files


def load(db, path: str) -> None:
    if not os.path.exists(path):
        return
    with open(path) as f:
        snapshot = json.load(f)

    for key, entry in snapshot.get("data", {}).items():
        value = entry["value"]
        if entry["type"] == "set":
            value = set(value)
        db.data[key] = value

    db.expires.update(snapshot.get("expires", {}))
