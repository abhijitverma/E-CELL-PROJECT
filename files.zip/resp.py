"""
resp.py — RESP (REdis Serialization Protocol) encoding and parsing.

This is the wire protocol real Redis uses. Because we speak it correctly,
any real Redis client (redis-cli, redis-py, etc.) can talk to our server.

Reference: https://redis.io/docs/reference/protocol-spec/

Wire format (RESP2, which is what we implement):
    +OK\r\n                     simple string
    -ERR message\r\n            error
    :1000\r\n                   integer
    $6\r\nfoobar\r\n            bulk string
    $-1\r\n                     null bulk string
    *2\r\n$3\r\nfoo\r\n$3\r\nbar\r\n   array
    *-1\r\n                     null array
"""


class SimpleString(str):
    """Marker type: encode as a RESP simple string (+OK\\r\\n) instead of
    a bulk string. Use for short status replies like OK, PONG, QUEUED."""
    __slots__ = ()


class RedisError(Exception):
    """Raised by a command handler to signal a RESP error reply (-ERR ...)."""
    pass


class ProtocolError(Exception):
    """Raised when the client sends bytes that don't parse as RESP/inline."""
    pass


def encode(value) -> bytes:
    """Encode a Python value into its RESP wire representation.

    Mapping:
        None            -> null bulk string ($-1\\r\\n)
        SimpleString    -> simple string (+...\\r\\n)
        bool            -> integer 0/1
        int             -> integer (:...\\r\\n)
        str / bytes     -> bulk string ($len\\r\\n...\\r\\n)
        list / tuple    -> array (*len\\r\\n...), recursively encoded
                           (a top-level None list means a null array)
    """
    if value is None:
        return b"$-1\r\n"
    if isinstance(value, SimpleString):
        return f"+{value}\r\n".encode()
    if isinstance(value, bool):
        return f":{int(value)}\r\n".encode()
    if isinstance(value, int):
        return f":{value}\r\n".encode()
    if isinstance(value, float):
        s = repr(value)
        data = s.encode()
        return b"$" + str(len(data)).encode() + b"\r\n" + data + b"\r\n"
    if isinstance(value, str):
        data = value.encode()
        return b"$" + str(len(data)).encode() + b"\r\n" + data + b"\r\n"
    if isinstance(value, bytes):
        return b"$" + str(len(value)).encode() + b"\r\n" + value + b"\r\n"
    if isinstance(value, NullArray):
        return b"*-1\r\n"
    if isinstance(value, (list, tuple)):
        parts = [f"*{len(value)}\r\n".encode()]
        for item in value:
            parts.append(encode(item))
        return b"".join(parts)
    raise TypeError(f"resp.encode: cannot encode value of type {type(value)!r}")


class NullArray:
    """Sentinel: encode as RESP's null array (*-1\\r\\n), distinct from an
    empty array (*0\\r\\n). Used e.g. by LPOP on a missing key with a count."""
    pass


def encode_error(message: str) -> bytes:
    if "\r" in message or "\n" in message:
        message = message.replace("\r", " ").replace("\n", " ")
    return f"-{message}\r\n".encode()


class RESPParser:
    """Incremental parser: feed() appends bytes, try_parse() pops one full
    command off the front of the buffer once enough bytes have arrived.

    Supports both:
      - the real RESP array-of-bulk-strings format every client library sends
      - the plain-text "inline command" format (space-separated, newline
        terminated) so you can talk to the server with `nc` or `telnet` too.
    """

    def __init__(self):
        self.buffer = b""

    def feed(self, data: bytes) -> None:
        self.buffer += data

    def try_parse(self):
        """Return a list of string args for one command, or None if the
        buffer doesn't yet contain a full command. Raises ProtocolError on
        malformed RESP. Consumes the parsed bytes from self.buffer only on
        success."""
        if not self.buffer:
            return None
        if self.buffer[0:1] == b"*":
            return self._parse_array()
        return self._parse_inline()

    def _parse_inline(self):
        idx = self.buffer.find(b"\n")
        if idx == -1:
            if len(self.buffer) > 64 * 1024:
                raise ProtocolError("too big inline request")
            return None
        line = self.buffer[:idx]
        self.buffer = self.buffer[idx + 1:]
        line = line.rstrip(b"\r")
        if not line:
            return []
        return line.decode(errors="replace").split()

    def _parse_array(self):
        head_end = self.buffer.find(b"\r\n")
        if head_end == -1:
            return None
        try:
            count = int(self.buffer[1:head_end])
        except ValueError:
            raise ProtocolError("invalid multibulk length")
        if count < 0:
            self.buffer = self.buffer[head_end + 2:]
            return []
        pos = head_end + 2
        args = []
        for _ in range(count):
            if pos >= len(self.buffer):
                return None
            if self.buffer[pos:pos + 1] != b"$":
                raise ProtocolError(f"expected '$', got '{chr(self.buffer[pos])}'")
            len_end = self.buffer.find(b"\r\n", pos)
            if len_end == -1:
                return None
            try:
                length = int(self.buffer[pos + 1:len_end])
            except ValueError:
                raise ProtocolError("invalid bulk length")
            start = len_end + 2
            end = start + length
            if end + 2 > len(self.buffer):
                return None
            args.append(self.buffer[start:end])
            pos = end + 2
        self.buffer = self.buffer[pos:]
        return [a.decode(errors="replace") for a in args]
