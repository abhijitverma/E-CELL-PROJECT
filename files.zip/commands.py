"""
commands.py — every supported Redis command, plus the COMMANDS dispatch
table that server.py uses to route incoming requests.

Each handler has the signature:

    def cmd_xxx(db: Database, args: list[str], server) -> RESP-able value

and either returns a plain Python value (str/int/list/None/SimpleString)
which resp.encode() knows how to serialize, or raises RedisError to send
back a RESP error reply.
"""

import time

from resp import SimpleString, RedisError, NullArray
import persistence

COMMANDS = {}


def command(*names):
    """Decorator: register a handler under one or more command names."""
    def deco(fn):
        for name in names:
            COMMANDS[name] = fn
        return fn
    return deco


def _wrong_args(name):
    raise RedisError(f"ERR wrong number of arguments for '{name.lower()}' command")


def _wrong_type():
    raise RedisError(
        "WRONGTYPE Operation against a key holding the wrong kind of value"
    )


def _need_str(db, key):
    v = db.get_raw(key)
    if v is None:
        return None
    if not isinstance(v, str):
        _wrong_type()
    return v


def _need_list(db, key, create=False):
    v = db.get_raw(key)
    if v is None:
        if create:
            v = []
            db.set_raw(key, v)
        return v
    if not isinstance(v, list):
        _wrong_type()
    return v


def _need_hash(db, key, create=False):
    v = db.get_raw(key)
    if v is None:
        if create:
            v = {}
            db.set_raw(key, v)
        return v
    if not isinstance(v, dict):
        _wrong_type()
    return v


def _need_set(db, key, create=False):
    v = db.get_raw(key)
    if v is None:
        if create:
            v = set()
            db.set_raw(key, v)
        return v
    if not isinstance(v, set):
        _wrong_type()
    return v


def _parse_int(s, what="value"):
    try:
        return int(s)
    except ValueError:
        raise RedisError(f"ERR {what} is not an integer or out of range")


# ---------------------------------------------------------------- misc ----

@command("PING")
def cmd_ping(db, args, server):
    if len(args) > 1:
        _wrong_args("PING")
    if args:
        return args[0]
    return SimpleString("PONG")


@command("ECHO")
def cmd_echo(db, args, server):
    if len(args) != 1:
        _wrong_args("ECHO")
    return args[0]


@command("SELECT")
def cmd_select(db, args, server):
    # Single logical database; accept 0, reject anything else like real
    # Redis does when the index is out of range.
    if len(args) != 1:
        _wrong_args("SELECT")
    idx = _parse_int(args[0], "index")
    if idx != 0:
        raise RedisError("ERR DB index is out of range")
    return SimpleString("OK")


@command("FLUSHALL", "FLUSHDB")
def cmd_flushall(db, args, server):
    db.flush()
    return SimpleString("OK")


@command("DBSIZE")
def cmd_dbsize(db, args, server):
    return db.size()


@command("KEYS")
def cmd_keys(db, args, server):
    if len(args) != 1:
        _wrong_args("KEYS")
    return sorted(db.keys_matching(args[0]))


@command("EXISTS")
def cmd_exists(db, args, server):
    if not args:
        _wrong_args("EXISTS")
    return sum(1 for k in args if db.exists(k))


@command("DEL")
def cmd_del(db, args, server):
    if not args:
        _wrong_args("DEL")
    return sum(1 for k in args if db.delete(k))


@command("TYPE")
def cmd_type(db, args, server):
    if len(args) != 1:
        _wrong_args("TYPE")
    return SimpleString(db.type_of(args[0]))


@command("COMMAND")
def cmd_command(db, args, server):
    # Real clients (redis-cli) probe this on connect for autocompletion.
    # An empty array keeps them happy without us having to describe every
    # command's arity/flags.
    return []


@command("CONFIG")
def cmd_config(db, args, server):
    # Minimal stub so `redis-cli CONFIG GET save` etc. doesn't error out.
    if args and args[0].upper() == "GET":
        return []
    return SimpleString("OK")


@command("INFO")
def cmd_info(db, args, server):
    lines = [
        "# Server",
        "redis_version:7.0.0-toy",
        "toy_redis_clone:1",
        f"tcp_port:{server.port if server else 0}",
        "# Keyspace",
        f"db0:keys={db.size()}",
    ]
    return "\r\n".join(lines) + "\r\n"


@command("SAVE")
def cmd_save(db, args, server):
    persistence.save(db, server.snapshot_path)
    return SimpleString("OK")


@command("BGSAVE")
def cmd_bgsave(db, args, server):
    persistence.save(db, server.snapshot_path)
    return SimpleString("Background saving started")


# ---------------------------------------------------------------- ttl -----

@command("EXPIRE")
def cmd_expire(db, args, server):
    if len(args) != 2:
        _wrong_args("EXPIRE")
    key, seconds = args
    if not db.exists(key):
        return 0
    db.set_expiry_at(key, time.time() + _parse_int(seconds, "value"))
    return 1


@command("PEXPIRE")
def cmd_pexpire(db, args, server):
    if len(args) != 2:
        _wrong_args("PEXPIRE")
    key, ms = args
    if not db.exists(key):
        return 0
    db.set_expiry_at(key, time.time() + _parse_int(ms, "value") / 1000.0)
    return 1


@command("TTL")
def cmd_ttl(db, args, server):
    if len(args) != 1:
        _wrong_args("TTL")
    return db.ttl_seconds(args[0])


@command("PTTL")
def cmd_pttl(db, args, server):
    if len(args) != 1:
        _wrong_args("PTTL")
    return db.ttl_millis(args[0])


@command("PERSIST")
def cmd_persist(db, args, server):
    if len(args) != 1:
        _wrong_args("PERSIST")
    return 1 if db.clear_expiry(args[0]) else 0


# --------------------------------------------------------------- string ---

@command("SET")
def cmd_set(db, args, server):
    if len(args) < 2:
        _wrong_args("SET")
    key, value = args[0], args[1]
    opts = [a.upper() for a in args[2:]]

    nx = "NX" in opts
    xx = "XX" in opts
    ex, px, keepttl = None, None, "KEEPTTL" in opts

    i = 0
    while i < len(opts):
        if opts[i] == "EX" and i + 1 < len(opts):
            ex = _parse_int(opts[i + 1], "value")
            i += 1
        elif opts[i] == "PX" and i + 1 < len(opts):
            px = _parse_int(opts[i + 1], "value")
            i += 1
        i += 1

    exists = db.exists(key)
    if nx and exists:
        return None
    if xx and not exists:
        return None

    db.set_raw(key, value)
    if ex is not None:
        db.set_expiry_at(key, time.time() + ex)
    elif px is not None:
        db.set_expiry_at(key, time.time() + px / 1000.0)
    elif not keepttl:
        db.clear_expiry(key)
    return SimpleString("OK")


@command("GET")
def cmd_get(db, args, server):
    if len(args) != 1:
        _wrong_args("GET")
    return _need_str(db, args[0])


@command("GETSET")
def cmd_getset(db, args, server):
    if len(args) != 2:
        _wrong_args("GETSET")
    key, value = args
    old = _need_str(db, key)
    db.set_raw(key, value)
    db.clear_expiry(key)
    return old


@command("APPEND")
def cmd_append(db, args, server):
    if len(args) != 2:
        _wrong_args("APPEND")
    key, value = args
    cur = _need_str(db, key) or ""
    new = cur + value
    db.set_raw(key, new)
    return len(new)


@command("STRLEN")
def cmd_strlen(db, args, server):
    if len(args) != 1:
        _wrong_args("STRLEN")
    v = _need_str(db, args[0])
    return len(v) if v is not None else 0


@command("INCR")
def cmd_incr(db, args, server):
    if len(args) != 1:
        _wrong_args("INCR")
    return _incr_by(db, args[0], 1)


@command("DECR")
def cmd_decr(db, args, server):
    if len(args) != 1:
        _wrong_args("DECR")
    return _incr_by(db, args[0], -1)


@command("INCRBY")
def cmd_incrby(db, args, server):
    if len(args) != 2:
        _wrong_args("INCRBY")
    return _incr_by(db, args[0], _parse_int(args[1]))


@command("DECRBY")
def cmd_decrby(db, args, server):
    if len(args) != 2:
        _wrong_args("DECRBY")
    return _incr_by(db, args[0], -_parse_int(args[1]))


def _incr_by(db, key, delta):
    cur = _need_str(db, key)
    n = 0 if cur is None else _parse_int(cur)
    n += delta
    db.set_raw(key, str(n))
    return n


# ----------------------------------------------------------------- list ---

@command("LPUSH")
def cmd_lpush(db, args, server):
    if len(args) < 2:
        _wrong_args("LPUSH")
    key, values = args[0], args[1:]
    lst = _need_list(db, key, create=True)
    for v in values:
        lst.insert(0, v)
    return len(lst)


@command("RPUSH")
def cmd_rpush(db, args, server):
    if len(args) < 2:
        _wrong_args("RPUSH")
    key, values = args[0], args[1:]
    lst = _need_list(db, key, create=True)
    lst.extend(values)
    return len(lst)


@command("LPOP")
def cmd_lpop(db, args, server):
    return _list_pop(db, args, "LPOP", from_left=True)


@command("RPOP")
def cmd_rpop(db, args, server):
    return _list_pop(db, args, "RPOP", from_left=False)


def _list_pop(db, args, name, from_left):
    if len(args) not in (1, 2):
        _wrong_args(name)
    key = args[0]
    count = _parse_int(args[1]) if len(args) == 2 else None
    lst = _need_list(db, key)
    if lst is None or len(lst) == 0:
        return NullArray() if count is not None else None
    if count is None:
        return lst.pop(0) if from_left else lst.pop()
    popped = []
    for _ in range(min(count, len(lst))):
        popped.append(lst.pop(0) if from_left else lst.pop())
    if not lst:
        db.delete(key)
    return popped


@command("LRANGE")
def cmd_lrange(db, args, server):
    if len(args) != 3:
        _wrong_args("LRANGE")
    key, start, stop = args[0], _parse_int(args[1]), _parse_int(args[2])
    lst = _need_list(db, key) or []
    n = len(lst)
    start = max(0, start + n) if start < 0 else start
    stop = stop + n if stop < 0 else stop
    stop = min(stop, n - 1)
    if start > stop or start >= n:
        return []
    return lst[start:stop + 1]


@command("LLEN")
def cmd_llen(db, args, server):
    if len(args) != 1:
        _wrong_args("LLEN")
    lst = _need_list(db, args[0])
    return len(lst) if lst else 0


@command("LINDEX")
def cmd_lindex(db, args, server):
    if len(args) != 2:
        _wrong_args("LINDEX")
    lst = _need_list(db, args[0]) or []
    idx = _parse_int(args[1])
    try:
        return lst[idx]
    except IndexError:
        return None


# ----------------------------------------------------------------- hash ---

@command("HSET")
def cmd_hset(db, args, server):
    if len(args) < 3 or len(args) % 2 == 0:
        _wrong_args("HSET")
    key = args[0]
    pairs = args[1:]
    h = _need_hash(db, key, create=True)
    added = 0
    for i in range(0, len(pairs), 2):
        field, value = pairs[i], pairs[i + 1]
        if field not in h:
            added += 1
        h[field] = value
    return added


@command("HGET")
def cmd_hget(db, args, server):
    if len(args) != 2:
        _wrong_args("HGET")
    h = _need_hash(db, args[0])
    return h.get(args[1]) if h else None


@command("HDEL")
def cmd_hdel(db, args, server):
    if len(args) < 2:
        _wrong_args("HDEL")
    key, fields = args[0], args[1:]
    h = _need_hash(db, key)
    if not h:
        return 0
    removed = 0
    for f in fields:
        if h.pop(f, None) is not None or f in h:
            removed += 1
    if not h:
        db.delete(key)
    return removed


@command("HGETALL")
def cmd_hgetall(db, args, server):
    if len(args) != 1:
        _wrong_args("HGETALL")
    h = _need_hash(db, args[0]) or {}
    out = []
    for k, v in h.items():
        out.append(k)
        out.append(v)
    return out


@command("HEXISTS")
def cmd_hexists(db, args, server):
    if len(args) != 2:
        _wrong_args("HEXISTS")
    h = _need_hash(db, args[0])
    return 1 if h and args[1] in h else 0


@command("HKEYS")
def cmd_hkeys(db, args, server):
    if len(args) != 1:
        _wrong_args("HKEYS")
    h = _need_hash(db, args[0]) or {}
    return list(h.keys())


@command("HVALS")
def cmd_hvals(db, args, server):
    if len(args) != 1:
        _wrong_args("HVALS")
    h = _need_hash(db, args[0]) or {}
    return list(h.values())


@command("HLEN")
def cmd_hlen(db, args, server):
    if len(args) != 1:
        _wrong_args("HLEN")
    h = _need_hash(db, args[0])
    return len(h) if h else 0


@command("HINCRBY")
def cmd_hincrby(db, args, server):
    if len(args) != 3:
        _wrong_args("HINCRBY")
    key, field, delta = args[0], args[1], _parse_int(args[2])
    h = _need_hash(db, key, create=True)
    cur = _parse_int(h.get(field, "0"))
    cur += delta
    h[field] = str(cur)
    return cur


# ------------------------------------------------------------------ set ---

@command("SADD")
def cmd_sadd(db, args, server):
    if len(args) < 2:
        _wrong_args("SADD")
    key, members = args[0], args[1:]
    s = _need_set(db, key, create=True)
    added = 0
    for m in members:
        if m not in s:
            s.add(m)
            added += 1
    return added


@command("SREM")
def cmd_srem(db, args, server):
    if len(args) < 2:
        _wrong_args("SREM")
    key, members = args[0], args[1:]
    s = _need_set(db, key)
    if not s:
        return 0
    removed = 0
    for m in members:
        if m in s:
            s.discard(m)
            removed += 1
    if not s:
        db.delete(key)
    return removed


@command("SMEMBERS")
def cmd_smembers(db, args, server):
    if len(args) != 1:
        _wrong_args("SMEMBERS")
    s = _need_set(db, args[0]) or set()
    return list(s)


@command("SISMEMBER")
def cmd_sismember(db, args, server):
    if len(args) != 2:
        _wrong_args("SISMEMBER")
    s = _need_set(db, args[0])
    return 1 if s and args[1] in s else 0


@command("SCARD")
def cmd_scard(db, args, server):
    if len(args) != 1:
        _wrong_args("SCARD")
    s = _need_set(db, args[0])
    return len(s) if s else 0
