"""
database.py — the in-memory data store.

One dict for the values, one dict for absolute expiry timestamps. Expiry is
checked lazily (on access) and also swept periodically by keys_matching(),
which mirrors how real Redis mixes lazy + active expiration.
"""

import fnmatch
import re
import time


class Database:
    def __init__(self):
        self.data: dict = {}
        self.expires: dict = {}  # key -> absolute unix timestamp (seconds)

    # ---- expiry -----------------------------------------------------

    def _expire_if_needed(self, key) -> bool:
        exp = self.expires.get(key)
        if exp is not None and time.time() >= exp:
            self.data.pop(key, None)
            self.expires.pop(key, None)
            return True
        return False

    def sweep_expired(self) -> None:
        now = time.time()
        expired = [k for k, exp in self.expires.items() if exp <= now]
        for k in expired:
            self.data.pop(k, None)
            self.expires.pop(k, None)

    # ---- generic key ops ---------------------------------------------

    def exists(self, key) -> bool:
        self._expire_if_needed(key)
        return key in self.data

    def get_raw(self, key):
        self._expire_if_needed(key)
        return self.data.get(key)

    def set_raw(self, key, value) -> None:
        self.data[key] = value

    def delete(self, key) -> bool:
        existed = self.exists(key)
        self.data.pop(key, None)
        self.expires.pop(key, None)
        return existed

    def set_expiry_at(self, key, when: float) -> None:
        self.expires[key] = when

    def clear_expiry(self, key) -> bool:
        return self.expires.pop(key, None) is not None

    def ttl_seconds(self, key) -> int:
        if not self.exists(key):
            return -2
        exp = self.expires.get(key)
        if exp is None:
            return -1
        return max(0, int(round(exp - time.time())))

    def ttl_millis(self, key) -> int:
        if not self.exists(key):
            return -2
        exp = self.expires.get(key)
        if exp is None:
            return -1
        return max(0, int(round((exp - time.time()) * 1000)))

    def keys_matching(self, pattern: str):
        self.sweep_expired()
        regex = _glob_to_regex(pattern)
        return [k for k in self.data if regex.match(k)]

    def type_of(self, key) -> str:
        if not self.exists(key):
            return "none"
        v = self.data[key]
        if isinstance(v, str):
            return "string"
        if isinstance(v, list):
            return "list"
        if isinstance(v, dict):
            return "hash"
        if isinstance(v, set):
            return "set"
        return "unknown"

    def flush(self) -> None:
        self.data.clear()
        self.expires.clear()

    def size(self) -> int:
        self.sweep_expired()
        return len(self.data)


def _glob_to_regex(pattern: str) -> "re.Pattern":
    return re.compile(fnmatch.translate(pattern))
