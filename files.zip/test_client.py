"""
test_client.py — a minimal RESP client used to smoke-test the server.

Run the server first, then:
    python3 test_client.py --port 6380

No external dependencies (no redis-py needed) — this speaks RESP by hand,
which doubles as a second, independent check that resp.py's wire format
is actually correct.
"""

import argparse
import socket
import sys


class TestClient:
    def __init__(self, host, port):
        self.sock = socket.create_connection((host, port), timeout=5)
        self.buf = b""

    def call(self, *args):
        parts = [f"*{len(args)}\r\n".encode()]
        for a in args:
            a = str(a).encode()
            parts.append(b"$" + str(len(a)).encode() + b"\r\n" + a + b"\r\n")
        self.sock.sendall(b"".join(parts))
        return self._read_reply()

    def _read_line(self):
        while b"\r\n" not in self.buf:
            chunk = self.sock.recv(4096)
            if not chunk:
                raise ConnectionError("server closed connection")
            self.buf += chunk
        line, self.buf = self.buf.split(b"\r\n", 1)
        return line

    def _read_exact(self, n):
        while len(self.buf) < n:
            chunk = self.sock.recv(4096)
            if not chunk:
                raise ConnectionError("server closed connection")
            self.buf += chunk
        data, self.buf = self.buf[:n], self.buf[n:]
        return data

    def _read_reply(self):
        line = self._read_line()
        kind, rest = line[0:1], line[1:]
        if kind == b"+":
            return rest.decode()
        if kind == b"-":
            return Exception(rest.decode())
        if kind == b":":
            return int(rest)
        if kind == b"$":
            length = int(rest)
            if length == -1:
                return None
            data = self._read_exact(length + 2)[:-2]
            return data.decode()
        if kind == b"*":
            count = int(rest)
            if count == -1:
                return None
            return [self._read_reply() for _ in range(count)]
        raise ValueError(f"unknown RESP type byte: {kind!r}")


PASS, FAIL = 0, 0


def check(label, actual, expected):
    global PASS, FAIL
    ok = actual == expected
    PASS += ok
    FAIL += not ok
    status = "ok " if ok else "FAIL"
    print(f"[{status}] {label}: got {actual!r}" + ("" if ok else f", want {expected!r}"))


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--host", default="127.0.0.1")
    ap.add_argument("--port", type=int, default=6380)
    args = ap.parse_args()

    c = TestClient(args.host, args.port)

    check("PING", c.call("PING"), "PONG")
    check("ECHO", c.call("ECHO", "hello"), "hello")

    c.call("FLUSHALL")
    check("SET", c.call("SET", "name", "claude"), "OK")
    check("GET", c.call("GET", "name"), "claude")
    check("GET missing", c.call("GET", "nope"), None)
    check("EXISTS", c.call("EXISTS", "name", "nope"), 1)
    check("APPEND", c.call("APPEND", "name", "-3"), 8)
    check("STRLEN", c.call("STRLEN", "name"), 8)

    check("INCR new", c.call("INCR", "counter"), 1)
    check("INCRBY", c.call("INCRBY", "counter", 9), 10)
    check("DECR", c.call("DECR", "counter"), 9)

    check("SET NX fails when exists", c.call("SET", "name", "x", "NX"), None)
    check("SET NX ok on new key", c.call("SET", "brandnew", "x", "NX"), "OK")

    check("EXPIRE", c.call("EXPIRE", "name", 100), 1)
    ttl = c.call("TTL", "name")
    check("TTL is in range", 0 < ttl <= 100, True)
    check("PERSIST", c.call("PERSIST", "name"), 1)
    check("TTL after PERSIST", c.call("TTL", "name"), -1)

    check("DEL", c.call("DEL", "brandnew"), 1)
    check("TYPE string", c.call("TYPE", "name"), "string")
    check("TYPE none", c.call("TYPE", "ghost"), "none")

    c.call("DEL", "mylist")
    check("RPUSH", c.call("RPUSH", "mylist", "a", "b", "c"), 3)
    check("LPUSH", c.call("LPUSH", "mylist", "z"), 4)
    check("LRANGE all", c.call("LRANGE", "mylist", 0, -1), ["z", "a", "b", "c"])
    check("LLEN", c.call("LLEN", "mylist"), 4)
    check("LPOP", c.call("LPOP", "mylist"), "z")
    check("RPOP", c.call("RPOP", "mylist"), "c")
    check("TYPE list", c.call("TYPE", "mylist"), "list")

    c.call("DEL", "myhash")
    check("HSET", c.call("HSET", "myhash", "f1", "v1", "f2", "v2"), 2)
    check("HGET", c.call("HGET", "myhash", "f1"), "v1")
    check("HGETALL", set(zip(c.call("HGETALL", "myhash")[::2],
                              c.call("HGETALL", "myhash")[1::2])),
          {("f1", "v1"), ("f2", "v2")})
    check("HEXISTS", c.call("HEXISTS", "myhash", "f1"), 1)
    check("HDEL", c.call("HDEL", "myhash", "f1"), 1)
    check("HLEN", c.call("HLEN", "myhash"), 1)

    c.call("DEL", "myset")
    check("SADD", c.call("SADD", "myset", "a", "b", "a"), 2)
    check("SISMEMBER", c.call("SISMEMBER", "myset", "a"), 1)
    check("SCARD", c.call("SCARD", "myset"), 2)
    check("SREM", c.call("SREM", "myset", "a"), 1)

    check("WRONGTYPE", type(c.call("LPUSH", "name", "x")), Exception)

    check("unknown command errors", type(c.call("NOTACOMMAND")), Exception)

    check("DBSIZE > 0", c.call("DBSIZE") > 0, True)

    print(f"\n{PASS} passed, {FAIL} failed")
    sys.exit(1 if FAIL else 0)


if __name__ == "__main__":
    main()
